# Ratcheting of sand — reproducible models

These files accompany the manual example *Ratcheting of Sand Under Low
Confinement*.  Each `.supan` file is a complete, runnable model; no external
scripts or data files are needed.

## Contents

```
ratcheting-0p05.supan    tau_a = 0.05 kPa
ratcheting-0p10.supan    tau_a = 0.10 kPa
ratcheting-0p15.supan    tau_a = 0.15 kPa
```

All three models use $$G_r=0.002$$ and $$A_0=-0.3$$ (contractive dilatancy).
Each establishes a low confinement of $$p'_0=2$$ kPa and a mean shear stress
of $$\tau_m=0.2$$ kPa, then applies 50 cycles of shear stress with zero-mean
amplitude $$\tau_a$$:

```text
material DafaliasManzari 1 125 .05 1.25 .02 .9 .7 .01 7 .1 .9 1.1 -.3 3.5 4 600 -130 .002
materialTestByLoadWithBase3D 1 -2 -2 -2 0 0 .2 0 0 0 0 0 .002 100 100 100 ...
exit
```

The twelve numbers after the tag are the six base stresses and the six stress
increments.  The shear increment is applied in 100 substeps per half cycle;
the other two models use increments of `0.001` and `0.003` kPa.

The non-zero mean shear stress drives ratcheting: the stress-strain loops
migrate towards larger strain every cycle.  The peak strain after 50 cycles is
3.3, 5.9 and 8.1 times the first-cycle value for the three amplitudes.

## Run

```bash
suanPan -nu -f ratcheting-0p10.supan
```

The strain-stress history is written to `RESULT.txt`: six strain components
followed by six stress components per row.  The first row is the zero state and
the second is the state after the base load.  Each subsequent block of 200 rows
is one complete cycle.  From these columns the peak shear strain
$$\gamma_{\max}=\max\varepsilon_{13}$$ and the effective stress path can be
computed.
