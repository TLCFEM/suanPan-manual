Duncan-Selig example models
===========================

All stress quantities are in kPa, lengths in metres, friction angles in radians.

1) Drained triaxial compression (one CP4 element, plane strain):

   cd triaxial
   suanPan -f duncanselig.supan
   suanPan -f bilineardp.supan

   Each run writes R1-RF.h5 (time + reaction of nodes 3 and 4),
   R2-E.h5 (strain) and R3-PE.h5 (plastic strain of the DP model).
   With sigma_3 = 300 kPa, q = -(RF_y,3 + RF_y,4) - 300.

2) Strip footing settlement (2 m wide, q = 100 kPa, 60 CP4 elements):

   cd footing
   suanPan -f footing.supan

   Run from the footing directory: nodes.supan, elements.supan and
   footing.amplitude are resolved relative to the current directory.
   The footing-induced settlement of the centre node is
   u_y(t = 3) - u_y(t = 1), read from R1-U.h5, dataset R1-U6.

   NOTE: set symm_mat 0 is essential.  The Duncan-Selig consistent tangent
   (and the non-associated Drucker-Prager tangent) is not symmetric.

3) Textbook reference:

   cd reference
   python3 settlement.py

   Only numpy is required; the script evaluates the Boussinesq strip stress
   and performs the 1D layer-wise integration described in the manual page.
