"""Textbook 1D layer-wise settlement of a strip footing on Duncan-Selig soil.

Only numpy is required.  Run with ``python3 settlement.py``.

The state of stress beneath a point at horizontal offset x and depth z is
approximated by the usual geotechnical 1D (oedometer) idealisation:

  * vertical stress      sigma_v = gamma*z + delta_sigma_z
  * lateral stress       sigma_3 = K0*sigma_v,  K0 = 1 - sin(phi_i)
  * deviator stress      sigma_d = sigma_v - sigma_3

The increment delta_sigma_z is the Boussinesq solution for a uniformly loaded
strip of half width a.  Each 0.25 m layer is integrated with the stress
dependent, degradation-modified constrained modulus of the Duncan-Selig model.
"""

import numpy as np

# Duncan-Selig parameters (kPa, radians) -- same as material line in footing.supan
PA, ER, N, BR, M, PHI_I, DPHI, RF, COH = 100.0, 40000.0, 0.6, 27000.0, 0.2, 0.7, 0.1, 0.7, 3.0
# problem data
Q, A, GAMMA, DEPTH, DZ = 100.0, 1.0, 18.0, 8.0, 0.25
K0 = 1.0 - np.sin(PHI_I)


def stress_increment(x, z):
    """Boussinesq vertical stress increment below a strip load -a <= xi <= a."""
    u1, u2 = -A - x, A - x
    return Q / np.pi * (
        z * (u2 / (u2 * u2 + z * z) - u1 / (u1 * u1 + z * z))
        + np.arctan(u2 / z) - np.arctan(u1 / z)
    )


def constrained_modulus(sigma_v):
    """M = d(sigma_v)/d(eps_v) under zero lateral strain, with hyperbolic degradation."""
    sigma_3 = K0 * sigma_v
    sigma_d = sigma_v - sigma_3
    phi = max(PHI_I - DPHI * np.log10(max(sigma_3 / PA, 1e-3)), 0.0)
    q_u = 2.0 / RF * (COH * np.cos(phi) + max(sigma_3, 0.0) * np.sin(phi)) / (1.0 - np.sin(phi))
    ei = ER * (max(sigma_3, 0.0) / PA) ** N
    b = BR * (max(sigma_3, 0.0) / PA) ** M
    e = ei * max(1.0 - sigma_d / q_u, 0.1) ** 2
    return 3.0 * b * (3.0 * b + e) / (9.0 * b - e)


def settlement(x):
    z = np.arange(DZ / 2, DEPTH, DZ)
    total = 0.0
    for zz in z:
        d_sigma = stress_increment(x, zz)
        path = np.linspace(GAMMA * zz, GAMMA * zz + d_sigma, 40)
        total += np.trapezoid(1.0 / np.array([constrained_modulus(s) for s in path]), path) * DZ
    return total


if __name__ == "__main__":
    print(f"K0 = {K0:.4f}")
    print(f"centre settlement (degraded modulus) = {1000 * settlement(0.0):.2f} mm")
    for x in (0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0):
        print(f"x = {x:4.1f} m   s = {1000 * settlement(x):6.2f} mm")
