/*
 * Standalone single-element undrained cyclic simple shear driver for the
 * DafaliasManzari material model of suanPan.
 *
 * This program links directly against the suanPan material library so that the
 * strain path can be prescribed exactly (constant-volume simple shear), which
 * is not directly expressible with a standard suanPan FE model file.
 *
 * Strain path
 * -----------
 *   Phase 1: isotropic drained consolidation, strain increment
 *            (-c, -c, -c, 0, 0, 0) repeated NCONS times.
 *   Phase 2: undrained cyclic simple shear, strain increment
 *            (0, 0, 0, 0, 0, +/- dgam) repeated NCYC times.
 *            The volumetric strain is exactly zero in this phase, so the
 *            change of mean effective stress is entirely due to the plastic
 *            volumetric strain (pore-pressure generation).
 *
 * Build: see build.sh.  Run: see README.md.
 */
#include <Material/Material3D/Sand/DafaliasManzari.h>

#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <memory>
#include <string>

int main(int argc, char** argv) {
    if(argc < 19) {
        std::cerr << "usage: driver OUT.csv G0 NU AC LC E0 XI M H0 H1 CH NB A0 ND ZM CZ PAT GR\n";
        return 1;
    }
    const std::string out = argv[1];
    auto** a = argv + 2;
    auto mat = std::make_unique<DafaliasManzari>(
        1u, std::stod(a[0]), std::stod(a[1]), std::stod(a[2]), std::stod(a[3]),
        std::stod(a[4]), std::stod(a[5]), std::stod(a[6]), std::stod(a[7]),
        std::stod(a[8]), std::stod(a[9]), std::stod(a[10]), std::stod(a[11]),
        std::stod(a[12]), std::stod(a[13]), std::stod(a[14]), std::stod(a[15]),
        std::stod(a[16]));
    mat->initialize_base(nullptr);
    mat->initialize(nullptr);
    mat->set_initialized(true);

    const auto ncons = std::getenv("NCONS") ? std::stoi(std::getenv("NCONS")) : 200;
    const auto decons = std::getenv("DECONS") ? std::stod(std::getenv("DECONS")) : -1.5E-5;
    const auto ncyc = std::getenv("NCYC") ? std::stoi(std::getenv("NCYC")) : 20;
    const auto nper = std::getenv("NPER") ? std::stoi(std::getenv("NPER")) : 40;
    const auto dgam = std::getenv("DGAM") ? std::stod(std::getenv("DGAM")) : 5E-5;

    const auto record = [&](std::ofstream& f, int step, double gamma, double p0) {
        const vec& s = mat->get_current_stress();
        const auto p = (s(0) + s(1) + s(2)) / 3.;
        const vec dev = s - p * vec({1., 1., 1., 0., 0., 0.});
        const auto q = std::sqrt(1.5 * (dev(0) * dev(0) + dev(1) * dev(1) + dev(2) * dev(2)
                     + 2. * (dev(3) * dev(3) + dev(4) * dev(4) + dev(5) * dev(5))));
        const vec& e = mat->get_current_strain();
        const auto ru = (p0 != 0.) ? 1. - p / p0 : 0.;
        f << step << ',' << gamma << ',' << (e(0) + e(1) + e(2)) << ','
          << p << ',' << q << ',' << ru << ','
          << s(0) << ',' << s(1) << ',' << s(2) << ',' << s(5) << '\n';
    };

    std::ofstream f(out);
    f << "step,gamma,ev,p,q,ru,s11,s22,s33,s13\n";

    for(int i = 0; i < ncons; ++i) {
        if(SUANPAN_SUCCESS != mat->update_incre_status(vec{decons, decons, decons, 0., 0., 0.})) return 2;
        mat->commit_status();
    }
    const vec& sc = mat->get_current_stress();
    const auto p0 = (sc(0) + sc(1) + sc(2)) / 3.;
    double gamma = 0.;
    record(f, -1, gamma, p0);

    int step = 0;
    const auto advance = [&](double dg) {
        if(SUANPAN_SUCCESS != mat->update_incre_status(vec{0., 0., 0., 0., 0., dg})) std::exit(3);
        mat->commit_status();
        gamma += dg;
        record(f, step++, gamma, p0);
    };
    for(int c = 0; c < ncyc; ++c) {
        for(int i = 0; i < nper / 2; ++i) advance(dgam);
        for(int i = 0; i < nper; ++i) advance(-dgam);
        for(int i = 0; i < nper / 2; ++i) advance(dgam);
    }
    f.close();
    std::cout << "p0 = " << p0 << " kPa, " << step << " shear increments\n";
    return 0;
}
