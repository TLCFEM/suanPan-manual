import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT = '/bEDD/u/tchang/suanPan-manual/docs/Example/Geotechnical/'
COL = {'a01': '#1f77b4', 'a03': '#d62728', 'a05': '#2ca02c', 'pos01': '#9467bd'}

def load(name):
    return np.genfromtxt(name + '.csv', delimiter=',', names=True)

# --- stress-strain loops (A0 = -0.3) ---
d = load('a03')
p0 = d['p'][1]
gam = d['gamma'][1:] * 100.0        # percent
tau = d['s13'][1:]                   # shear stress (kPa)
fig, ax = plt.subplots(figsize=(6, 4.6))
for c in [0, 2, 5, 9, 14]:
    s = slice(1 + c*80, 1 + (c+1)*80)
    ax.plot(gam[s], tau[s], lw=1.2, label=f'cycle {c+1}')
ax.axhline(0, color='k', lw=.5)
ax.axvline(0, color='k', lw=.5)
ax.set_xlabel(r'shear strain $\gamma$ (%)')
ax.set_ylabel(r'shear stress $\tau$ (kPa)')
ax.set_title(r'Loose sand, $A_0=-0.3$: stress-strain loops')
ax.legend(fontsize=8, loc='upper right')
ax.grid(alpha=.3)
fig.tight_layout()
fig.savefig(OUT + 'liquefaction-stress-strain.svg', format='svg')
plt.close(fig)

# --- effective stress path (A0 = -0.3) ---
d = load('a03')
p = d['p'][1:]
q = d['q'][1:]
fig, ax = plt.subplots(figsize=(5.6, 4.6))
ax.plot(p, q, lw=.7, color='#d62728')
ax.plot(p[0], q[0], 'o', color='k', ms=5, label=r'after consolidation ($p_0^{\prime}=-143$ kPa)')
ax.plot(0, 0, '*', color='k', ms=12, label='liquefaction')
ax.set_xlabel(r'mean effective stress $p^{\prime}$ (kPa)')
ax.set_ylabel(r'deviatoric stress $q$ (kPa)')
ax.set_title(r'Loose sand, $A_0=-0.3$: effective stress path')
ax.legend(fontsize=8)
ax.grid(alpha=.3)
fig.tight_layout()
fig.savefig(OUT + 'liquefaction-effective-stress-path.svg', format='svg')
plt.close(fig)

# --- pore pressure ratio: parameter study ---
fig, ax = plt.subplots(figsize=(7, 4.6))
for name, label in [('a01', r'$A_0=-0.1$ (slow)'), ('a03', r'$A_0=-0.3$'),
                    ('a05', r'$A_0=-0.5$ (fast)'), ('pos01', r'$A_0=+0.1$ (dilative)')]:
    d = load(name)
    p0 = d['p'][1]
    p = d['p'][1:]
    ru = 1. - p / p0
    cyc = np.arange(len(ru)) / 80. + 1.
    ax.plot(cyc, ru, lw=1.3, color=COL[name], label=label)
ax.axhline(1., color='k', ls='--', lw=1, label=r'$r_u=1$ (liquefaction)')
ax.set_xlim(1, 20)
ax.set_ylim(-1.6, 1.1)
ax.set_xlabel('number of shear cycles')
ax.set_ylabel(r'excess pore pressure ratio $r_u$')
ax.set_title('Role of the dilatancy constant $A_0$ ( Toyoura sand, $\\gamma_a=0.1\\%$ )')
ax.legend(fontsize=8, loc='lower left', ncol=2)
ax.grid(alpha=.3)
fig.tight_layout()
fig.savefig(OUT + 'liquefaction-pore-pressure.svg', format='svg')
plt.close(fig)
print('figures written')
