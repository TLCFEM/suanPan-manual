#!/usr/bin/env bash
# Build the standalone single-element driver against an existing suanPan build.
# Adjust SUANPAN to point at the source tree and BUILD to its build directory.
set -e
SUANPAN=${SUANPAN:-../suanPan}
BUILD=${BUILD:-$SUANPAN/build}

CXX=${CXX:-/usr/bin/c++}
INC="-I$SUANPAN -I$SUANPAN/Include -I$SUANPAN/Include/fmt/include -I$SUANPAN/Include/hdf5 -I$SUANPAN/Include/hdf5-linux"
FLAGS="-DARMA_DONT_CHECK_CONFORMANCE -DSUANPAN_AVX2 -mavx2 -O2 -std=gnu++20 -flto=auto -fno-fat-lto-objects"

$CXX $FLAGS $INC -c driver.cpp -o driver.o

OBJS=$(find "$BUILD/CMakeFiles/suanPan.dir" -name '*.o' | sort | tr '\n' ' ')
$CXX -fexceptions -mavx2 -O2 -flto=auto -fno-fat-lto-objects \
     -Wl,-init,gotoblas_init -Wl,--export-dynamic -rdynamic -Wl,--allow-multiple-definition \
     driver.o $OBJS -o driver \
     -L$SUANPAN/Libs/linux -Wl,-rpath,$SUANPAN/Libs/linux \
     -lhdf5 -lopenblas "$BUILD/Libs/libfext.a" "$BUILD/Libs/libsuperlu.a" \
     -lhdf5 -lopenblas -lgomp -lgfortran -lquadmath

echo "built ./driver"
