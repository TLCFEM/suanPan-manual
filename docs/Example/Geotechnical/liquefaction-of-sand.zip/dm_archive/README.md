# Liquefaction of sand — reproducible files

This archive accompanies the manual example *Liquefaction of Sand Under Cyclic
Simple Shear*.

## Contents

```
reference/
  driver.cpp          standalone single-element undrained simple-shear driver
  build.sh            compile driver.cpp against a suanPan source/build tree
  plot_results.py     reproduce the three SVG figures from the CSV data
  data/               simulation results (one CSV per A0 value)
    a01.csv           A0 = -0.1
    a03.csv           A0 = -0.3
    a05.csv           A0 = -0.5
    pos01.csv         A0 = +0.1
models/
  consolidation.supan runnable suanPan model: one-element consolidation
```

CSV columns: `step, gamma, ev, p, q, ru, s11, s22, s33, s13`, where `gamma` is
the engineering shear strain, `ev` the volumetric strain, `p` the mean effective
stress, `q` the deviatoric stress, `ru = 1 - p/p0` the excess pore-pressure ratio
and `s13` the shear stress.

## Rebuild the driver

The driver links against the material library of an existing suanPan build:

```bash
cd reference
SUANPAN=/path/to/suanPan BUILD=/path/to/suanPan/build bash build.sh
```

Set `OPENBLAS_NUM_THREADS=1` when running to avoid BLAS thread oversubscription
on this very small problem.

## Reproduce the data

```bash
# Toyoura sand, p0 ~= 143 kPa, shear strain amplitude 0.1%, 20 cycles
NCONS=200 NCYC=20 NPER=40 DGAM=5E-5 \
  ./driver a03.csv 125 .05 1.25 .02 .9 .7 .01 7 .1 .9 1.1 -.3 3.5 4 600 -130 .2
```

Change the 13th argument (`A0`) to `-0.1`, `-0.5` or `+0.1` for the other cases.

## Reproduce the figures

```bash
python3 plot_results.py
```

The script writes `liquefaction-*.svg` into the current directory.
