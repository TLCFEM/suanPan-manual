import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT = '/bEDD/u/tchang/suanPan-manual/docs/Example/Geotechnical/'
BASE = '/tmp/opencode/dm_scratch/native/'
COL = {'n01': '#1f77b4', 'n03': '#d62728', 'n05': '#2ca02c', 'np01': '#9467bd'}

def load(name):
    return np.loadtxt(BASE + name + '.csv')

def invariants(r):
    s11, s22, s33, s12, s23, s13 = r[:, 6:12].T
    p = (s11 + s22 + s33) / 3.
    dev = np.stack([s11 - p, s22 - p, s33 - p, s12, s23, s13], axis=1)
    q = np.sqrt(1.5 * np.sum(dev[:, :3]**2 + 2 * dev[:, 3:]**2, axis=1))
    return p, q

# stress-strain loops
r = load('n03')
gamma, tau = r[:, 5] * 100., r[:, 11]
fig, ax = plt.subplots(figsize=(6, 4.6))
for c, label in zip([0, 2, 5, 9, 14], [1, 3, 6, 10, 15]):
    s = slice(21 + c * 80, 21 + (c + 1) * 80)
    ax.plot(gamma[s], tau[s], lw=1.2, label=f'cycle {label}')
ax.axhline(0, color='k', lw=.5)
ax.axvline(0, color='k', lw=.5)
ax.set_xlabel(r'shear strain $\gamma$ (%)')
ax.set_ylabel(r'shear stress $\tau$ (kPa)')
ax.set_title(r'Loose sand, $A_0=-0.3$: stress-strain loops')
ax.legend(fontsize=8, loc='upper right')
ax.grid(alpha=.3)
fig.tight_layout()
fig.savefig(OUT + 'liquefaction-stress-strain.svg', format='svg')
plt.close(fig)

# effective stress path
r = load('n03')
p, q = invariants(r)
fig, ax = plt.subplots(figsize=(5.6, 4.6))
ax.plot(p, q, lw=.7, color='#d62728')
ax.plot(p[1], q[1], 'o', color='k', ms=5, label=r'after consolidation ($p_0^{\prime}=-130$ kPa)')
ax.plot(0, 0, '*', color='k', ms=12, label='liquefaction')
ax.set_xlabel(r'mean effective stress $p^{\prime}$ (kPa)')
ax.set_ylabel(r'deviatoric stress $q$ (kPa)')
ax.set_title(r'Loose sand, $A_0=-0.3$: effective stress path')
ax.legend(fontsize=8)
ax.grid(alpha=.3)
fig.tight_layout()
fig.savefig(OUT + 'liquefaction-effective-stress-path.svg', format='svg')
plt.close(fig)

# pore pressure ratio: parameter study
fig, ax = plt.subplots(figsize=(7, 4.6))
for name, label in [('n01', r'$A_0=-0.1$ (slow)'), ('n03', r'$A_0=-0.3$'),
                    ('n05', r'$A_0=-0.5$ (fast)'), ('np01', r'$A_0=+0.1$ (dilative)')]:
    r = load(name)
    p, q = invariants(r)
    p0 = p[1]
    ru = 1. - p / p0
    cyc = np.arange(len(ru)) / 80.
    ax.plot(cyc, ru, lw=1.3, color=COL[name], label=label)
ax.axhline(1., color='k', ls='--', lw=1, label=r'$r_u=1$ (liquefaction)')
ax.set_xlim(0, 20)
ax.set_ylim(-1.8, 1.1)
ax.set_xlabel('number of shear cycles')
ax.set_ylabel(r'excess pore pressure ratio $r_u$')
ax.set_title(r'Role of the dilatancy constant $A_0$ (Toyoura sand, $\gamma_a=0.1\%$)')
ax.legend(fontsize=8, loc='lower left', ncol=2)
ax.grid(alpha=.3)
fig.tight_layout()
fig.savefig(OUT + 'liquefaction-pore-pressure.svg', format='svg')
plt.close(fig)
print('figures regenerated from native suanPan results')
