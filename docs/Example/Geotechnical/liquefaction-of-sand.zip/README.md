# Liquefaction of sand — reproducible models

These files accompany the manual example *Liquefaction of Sand Under Cyclic
Simple Shear*.  Each `.supan` file is a complete, runnable model: no external
scripts or data files are required.

## Contents

```
n01.supan    A0 = -0.1   (slow pore-pressure build-up)
n03.supan    A0 = -0.3   (liquefaction after about 12 cycles)
n05.supan    A0 = -0.5   (liquefaction after about 7 cycles)
np01.supan   A0 = +0.1   (dilative, no liquefaction)
```

All four models use the same parameters except the dilatancy constant $A_0$.
Each applies a base isotropic strain (consolidation) and then 20 symmetric
cycles of constant-volume simple shear:

```text
material DafaliasManzari 1 125 .05 1.25 .02 .9 .7 .01 7 .1 .9 1.1 -.3 3.5 4 600 -130 .2
materialTestWithBase3D 1 -1.5E-3 -1.5E-3 -1.5E-3 0 0 0 0 0 0 0 0 5E-5 20 40 40 ... 40
exit
```

The base strain gives $p'_0\approx-130$ kPa; the shear strain amplitude is
$\gamma_a=0.1\%$.  The constant-volume shear path is undrained by construction,
so the excess pore pressure is $u=\Delta(-p')$ and the pore-pressure ratio is
$r_u=1-p'/p'_0$.

## Run

```bash
suanPan -nu -f n03.supan
```

The strain-stress history is written to `RESULT.txt`: six strain components
followed by six stress components per row.  The first row is the zero state,
the second is the state after consolidation, and the remaining rows are the
cyclic shear history.  The figures in the manual are obtained from these
columns by computing $p'=(\sigma_{11}+\sigma_{22}+\sigma_{33})/3$,
$q=\sqrt{3J_2}$, $\tau=\sigma_{13}$ and $r_u=1-p'/p'_0$.
