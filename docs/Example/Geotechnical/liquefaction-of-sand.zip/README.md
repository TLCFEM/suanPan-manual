# Liquefaction of sand — reproducible files

This archive accompanies the manual example *Liquefaction of Sand Under Cyclic
Simple Shear*.  All results are produced with the standard `suanPan` executable;
no external driver is required.

## Contents

```
models/
  n01.supan       A0 = -0.1
  n03.supan       A0 = -0.3
  n05.supan       A0 = -0.5
  np01.supan      A0 = +0.1
reference/
  plot_results.py   reproduce the three SVG figures from the CSV data
  dm_tangent_fix.patch  proposed fix for the rank-deficient tension-cap
                        tangent (apply to the suanPan source with `git apply`)
  data/             simulation results (one CSV per A0 value)
```

Each model applies a base isotropic strain (consolidation) and then 20 symmetric
cycles of constant-volume simple shear via `materialTestWithBase3D`:

```text
material DafaliasManzari 1 125 .05 1.25 .02 .9 .7 .01 7 .1 .9 1.1 -.3 3.5 4 600 -130 .2
materialTestWithBase3D 1 -1.5E-3 -1.5E-3 -1.5E-3 0 0 0 0 0 0 0 0 5E-5 \
    40 40 40 40 40 40 40 40 40 40
exit
```

The base strain gives $p'_0 \approx -130$ kPa; the shear strain amplitude is
$\gamma_a = 0.1\%$ (40 increments of $5\times10^{-5}$ per half cycle).
Use the patched suanPan build (see `dm_tangent_fix.patch`) so the tension-cap
tangent keeps full rank.

## Reproduce

```bash
cd models
for f in n01 n03 n05 np01; do
  suanPan -nu -f $f.supan
  mv RESULT.txt ../reference/data/$f.csv
done
cd ../reference
python3 plot_results.py
```

`RESULT.txt` columns are: strain (6) then stress (6).  The plot script converts
these to the pore-pressure ratio $r_u=1-p'/p'_0$ and the effective stress path.
