# Cyclic shear and shakedown of sand — reproducible models

These files accompany the manual example *Cyclic Shear and Shakedown of Sand*.
Each `.supan` file is a complete, runnable model; no external scripts or data
files are needed.

## Contents

```
cyclic-shear-1e-5.supan    gamma_a = 0.001%   (peak tau ~= 2.7 kPa)
cyclic-shear-3e-5.supan    gamma_a = 0.003%   (peak tau ~= 6.7 kPa)
cyclic-shear-1e-4.supan    gamma_a = 0.01%    (peak tau ~= 20 kPa)
```

All three models use $G_r=0.01$ and $A_0=0$ (neutral dilatancy).  Each first
consolidates a sand element to $p'_0\approx130$ kPa by an isotropic base strain
of $-1.5\times10^{-3}$, then applies 50 symmetric cycles of constant-volume
simple shear:

```text
material DafaliasManzari 1 125 .05 1.25 .02 .9 .7 .01 7 .1 .9 1.1 0 3.5 4 600 -130 .01
materialTestWithBase3D 1 -1.5E-3 -1.5E-3 -1.5E-3 0 0 0 0 0 0 0 0 1E-5 20 40 40 ...
exit
```

The twelve numbers after the tag are the six base strains and the six strain
increments.  The shear increment is applied in 40 substeps per half cycle;
the other two models use increments of `3E-5` and `1E-4`.

Because $A_0=0$, no excess pore pressure is generated and $p'$ stays at
130 kPa — the cyclic response is pure deviatoric shakedown.

## Run

```bash
suanPan -nu -f cyclic-shear-3e-5.supan
```

The strain-stress history is written to `RESULT.txt`: six strain components
followed by six stress components per row.  The first row is the zero state and
the second is the state after consolidation.  Each subsequent block of 80 rows
is one half cycle.  From these columns the peak stress, the loop area
$\oint\tau\,d\gamma$ and the $p'$–$q$ path can be computed; the loops close and
the path is retraced after the first few cycles, which is the signature of
shakedown.
