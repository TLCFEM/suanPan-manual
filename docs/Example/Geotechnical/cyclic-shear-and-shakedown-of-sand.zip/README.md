# Cyclic shear and shakedown of sand — reproducible models

These files accompany the manual example *Cyclic Shear and Shakedown of Sand*.
Each `.supan` file is a complete, runnable model; no external scripts or data
files are needed.

## Contents

```
cyclic-shear-1kPa.supan    tau_a = 1 kPa
cyclic-shear-3kPa.supan    tau_a = 3 kPa
cyclic-shear-8kPa.supan    tau_a = 8 kPa
```

All three models consolidate a sand element to $p'_0 = 130$ kPa and then apply
50 symmetric cycles of shear stress with zero mean, from $-\tau_a$ to $+\tau_a$.
The normal stresses are held constant, so the test is drained.
For $\tau_a = 1$ kPa the command is

```text
material DafaliasManzari 1 125 .05 1.25 .02 .9 .7 .01 7 .1 .9 1.1 -.3 3.5 4 600 -130 .2
materialTestByLoadWithBase3D 1 -130 -130 -130 0 0 -1 0 0 0 0 0 .02 100 100 100 ...
exit
```

The first six numbers after the tag are the base stress, the next six are the
stress increment per substep, and the remaining numbers are the reversal counts
(100 substeps per half cycle, 50 cycles).  With an increment of $0.02$ kPa the
shear stress moves from $-1$ to $+1$ kPa in 100 steps.  The other two models use
base shear stresses of $-3$ and $-8$ kPa with increments of $0.06$ and $0.16$ kPa.

## Run

```bash
suanPan -nu -f cyclic-shear-3kPa.supan
```

The strain-stress history is written to `RESULT.txt`: six strain components
followed by six stress components per row.  The first row is the zero state and
the second is the state after consolidation.  Each subsequent block of 200 rows
is one complete shear cycle.  The peak shear strain is
$\gamma_{\max}=\max\varepsilon_{13}$ and the hysteresis area is
$\oint\tau\,d\gamma$ with $\tau=\sigma_{13}$; both stabilise after the first
few cycles, which is the signature of shakedown.
