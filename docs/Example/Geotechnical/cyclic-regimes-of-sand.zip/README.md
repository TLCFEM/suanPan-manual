# Shakedown, ratcheting and liquefaction — reproducible models

These files accompany the manual example *Shakedown, Ratcheting and
Liquefaction of Sand Under Cyclic Shear*.  Each `.supan` file is a complete,
runnable model; no external scripts or data files are needed.

## Contents

```
shakedown.supan      gamma_a = 0.004%   (mean effective stress stays constant)
ratcheting.supan     gamma_a = 0.01%    (mean effective stress decreases steadily)
liquefaction.supan   gamma_a = 0.02%    (mean effective stress reaches zero)
```

All three models use the same material parameters, including $$G_r=0.002$$ and
$$A_0=-0.3$$, and differ only in the cyclic strain amplitude.  Each first
consolidates a sand element to $$p'_0\approx533$$ kPa with a base strain of
$$-3\times10^{-3}$$, then applies 150 symmetric cycles of constant-volume
simple shear:

```text
material DafaliasManzari 1 125 .05 1.25 .02 .9 .7 .01 7 .1 .9 1.1 -.3 3.5 4 600 -130 .002
materialTestWithBase3D 1 -3E-3 -3E-3 -3E-3 0 0 0 0 0 0 0 0 2E-6 20 40 40 ...
exit
```

The twelve numbers after the tag are the six base strains and the six strain
increments.  The shear increment is applied in 40 substeps per half cycle;
the other two models use increments of `5E-6` and `1E-5`.

## Run

```bash
suanPan -nu -f liquefaction.supan
```

The strain-stress history is written to `RESULT.txt`: six strain components
followed by six stress components per row.  The first row is the zero state and
the second is the state after consolidation.  Each subsequent block of 80 rows
is one half cycle.  From these columns the mean effective stress
$$p'=(\sigma_{11}+\sigma_{22}+\sigma_{33})/3$$ and the deviatoric stress
$$q=\sqrt{3J_2}$$ are obtained; their paths show the transition from a fixed
vertical line to the curved envelope that collapses at the origin.
