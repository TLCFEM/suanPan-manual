node 1 0 0
node 2 0 1

material Elastic1D 1 100 .1

section Rectangle2D 1 12 1 1

element B21 1 1 2 1 6

mass 2 2 10 1

hdf5recorder 1 Node U1 1 2

amplitude Tabular 1 EZ