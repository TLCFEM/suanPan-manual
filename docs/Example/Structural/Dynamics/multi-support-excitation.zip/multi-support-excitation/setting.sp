step dynamic 1 30
set ini_step_size 1E-2
set fixed_step_size true

integrator Newmark 1

converger RelIncreDisp 1 1E-10 4 1

analyze

save recorder 1

exit