#include <fstream>
#include <random>
#include <sstream>
#include <iomanip>

int main(int argv, char **argc)
{
    std::ofstream output("Collision.supan");

    if (!output.is_open())
        return 0;

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis_u(-4.5, 4.5);
    std::uniform_real_distribution<> dis_v(-1., 1.);

    auto size = 100;
    if (argv > 1)
    {
        std::string tmp;
        tmp = argc[1];
        std::istringstream(tmp) >> size;
    }

    output << std::setprecision(4);

    for (int n = 1; n <= size; ++n)
    {
        output << "node " << n << ' ' << dis_u(gen) << ' ' << dis_u(gen) << '\n';
        output << "mass " << n << ' ' << n << " 1 1 2\n";
        output << "initial velocity " << dis_v(gen) << " 1 " << n << '\n';
        output << "initial velocity " << dis_v(gen) << " 2 " << n << "\n\n";
    }

    output << "hdf5recorder 1 Global KE\n";
    output << "hdf5recorder 2 Visualisation U every 20 width 4\n\n";

    output << "particlecollision2d 1 2.\n\n";

    output << "rigidwall 2 5 0 0 -1 0 0 1E0\nrigidwall 3 0 5 0 0 -1 0 1E0\nrigidwall 4 -5 0 0 1 0 0 1E0\nrigidwall 5 0 -5 0 0 1 0 1E0\n\n";

    output << "step dynamic 1 200\nset ini_step_size 2E-2\nset fixed_step_size 1\nset band_mat false\nset symm_mat false\n\nconverger RelIncreDisp 1 1E-11 10 1\n\n";

    output << "analyze\n\nsave recorder 1\n\nexit\n\n";

    return 0;
}