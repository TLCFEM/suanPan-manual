# Strip Footing on Sand Using DuncanSelig

This folder contains the model and scripts for the `DuncanSelig` strip-footing
example in the suanPan manual.

## Files

- `strip-footing-on-sand.supan` — baseline model: a 2 m strip footing on a 10 m
  sand layer, 20 x 20 `CP4` mesh, half-domain.
- `gravity.txt`, `footing.txt` — tabular amplitudes that ramp gravity during the
  first 20% of the step and the footing pressure over the remaining 80%.
- `generate.py` — regenerates the model and the amplitude files and can create
  the parameter variants.
- `plot.py` — reads the HDF5 recorder output, writes `load-settlement.svg` and
  `settlement-contour.svg`, and checks the footing load against the reactions.

Units are kN, m, kPa and t/m³. Angles in the model file are in radians.

## Run the baseline

```bash
suanPan -f strip-footing-on-sand.supan
```

The baseline material parameters are

```text
material DuncanSelig 1 101.3 40000 0.6 30000 0.2 0.6283 0.1396 0.8 0 1.8
```

The last two numbers are the cohesion (0 kPa) and the density (1.8 t/m³).

## Generate a variant

```bash
python generate.py variant --Er 80000
cd variant
suanPan -f strip-footing-on-sand.supan
```

The available options are `--Er`, `--n`, `--Br`, `--m`, `--phi`, `--dphi`,
`--rf`, `--c`, `--pressure`, `--gamma`, `--steps` and `--tol`. Friction angles
passed on the command line are in degrees and converted to radians.

## Convergence

The model uses `converger RelIncreDisp 1 1E-2 30 1`. The moduli depend on the
stress state, so the global iteration can settle into a very small two-cycle for
stiff parameter combinations. The resulting displacement error is on the order
of 1 µm per step. The baseline also runs with `--tol 1E-3`, and the settlement
changes by less than 0.01 mm, but stiffer variants such as `--Er 80000` may need
`1E-2` to converge within the iteration limit.

## Plot the result

```bash
python plot.py --pressure 200
```

The script requires `numpy`, `matplotlib` and `h5py`. It prints the settlement
and the footing pressure recovered from the sum of the vertical reactions.
