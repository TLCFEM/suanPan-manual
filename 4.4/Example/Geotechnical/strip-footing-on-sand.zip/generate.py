#!/usr/bin/env python3
"""Generate the plane-strain strip-footing model for the DuncanSelig example.

The mesh is a 5 m x 10 m half-domain.  The strip footing is 2 m wide, so its
half-width is 1 m.  Gravity is ramped during the first 20% of the single static
step; the footing pressure is held at zero over that interval and then ramped
to its target value.

Examples
--------
python generate.py baseline
python generate.py Er_2 --Er 80000
python generate.py phi_30 --phi 30
"""

from __future__ import annotations

import argparse
from math import radians
from pathlib import Path


def build(
    nx: int = 20,
    ny: int = 20,
    width: float = 5.0,
    depth: float = 10.0,
    footing: float = 1.0,
    gamma: float = 18.0,
    pressure: float = 200.0,
    steps: int = 60,
    tol: float = 1e-2,
    p_atm: float = 101.3,
    Er: float = 40000.0,
    n: float = 0.6,
    Br: float = 30000.0,
    m: float = 0.2,
    phi: float = 36.0,
    dphi: float = 8.0,
    rf: float = 0.8,
    c: float = 0.0,
    rho: float = 1.8,
) -> tuple[str, str, str]:
    dx = width / nx
    dy = depth / ny

    def tag(i: int, j: int) -> int:
        return j * (nx + 1) + i + 1

    lines = [
        "# Plane-strain strip footing on a Duncan-Selig sand layer",
        "# units: kN, m, kPa, t/m3",
        "",
    ]

    for j in range(ny + 1):
        for i in range(nx + 1):
            lines.append(f"node {tag(i, j)} {i * dx:.8g} {j * dy:.8g}")
    lines.append("")

    element = 0
    for j in range(ny):
        for i in range(nx):
            element += 1
            lines.append(
                f"element CP4 {element} {tag(i, j)} {tag(i + 1, j)} "
                f"{tag(i + 1, j + 1)} {tag(i, j + 1)} 1"
            )
    lines.append("")

    material = (
        f"material DuncanSelig 1 {p_atm:.8g} {Er:.8g} {n:.8g} {Br:.8g} {m:.8g} "
        f"{radians(phi):.8g} {radians(dphi):.8g} {rf:.8g} {c:.8g} {rho:.8g}"
    )
    lines.append(material)
    lines.append("")

    left = [tag(0, j) for j in range(ny + 1)]
    right = [tag(nx, j) for j in range(ny + 1)]
    bottom = [tag(i, 0) for i in range(nx + 1)]
    lines.append("fix 1 1 " + " ".join(map(str, left)))
    lines.append("fix 2 1 " + " ".join(map(str, right)))
    lines.append("fix 3 2 " + " ".join(map(str, bottom)))
    lines.append("")

    lines.append(f"generate elementgroup 1 1 {element}")
    lines.append(f"generate nodegroup 2 1 {tag(nx, ny)}")
    lines.append("")

    lines.append("amplitude Tabular 1 gravity.txt")
    lines.append("amplitude Tabular 2 footing.txt")
    lines.append("")

    lines.append("recorder 1 hdf5 GroupNode U 1 2")
    lines.append("recorder 2 hdf5 GroupNode RF 1 2")
    lines.append("")

    footing_nodes = [tag(i, ny) for i in range(nx + 1) if i * dx <= footing + 1e-9]
    lines += [
        "step static 1 1",
        "set fixed_step_size 1",
        f"set ini_step_size {1.0 / steps:.8g}",
        "set symm_mat 0",
        "set band_mat 0",
        "load groupbodyforce 1 1 -%g 2 1" % gamma,
        "lineudl2d 2 2 -%g 2 %s" % (pressure, " ".join(map(str, footing_nodes))),
        f"converger RelIncreDisp 1 {tol:.0E} 30 1",
        "analyze",
        "",
        "save recorder 1",
        "save recorder 2",
        "",
        f"peek node {tag(0, ny)}",
        "exit",
    ]

    gravity = "0 0\n0.2 1\n1 1\n"
    footing_amp = "0 0\n0.2 0\n1 1\n"
    return "\n".join(lines) + "\n", gravity, footing_amp


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path, nargs="?", default=Path("."))
    parser.add_argument("--pressure", type=float, default=200.0)
    parser.add_argument("--gamma", type=float, default=18.0)
    parser.add_argument("--nx", type=int, default=20)
    parser.add_argument("--ny", type=int, default=20)
    parser.add_argument("--steps", type=int, default=60)
    parser.add_argument("--Er", type=float, default=40000.0)
    parser.add_argument("--n", type=float, default=0.6)
    parser.add_argument("--Br", type=float, default=30000.0)
    parser.add_argument("--m", type=float, default=0.2)
    parser.add_argument("--phi", type=float, default=36.0)
    parser.add_argument("--dphi", type=float, default=8.0)
    parser.add_argument("--rf", type=float, default=0.8)
    parser.add_argument("--c", type=float, default=0.0)
    parser.add_argument("--tol", type=float, default=1e-2)
    args = parser.parse_args()

    args.output.mkdir(parents=True, exist_ok=True)
    model, gravity, footing = build(
        nx=args.nx,
        ny=args.ny,
        gamma=args.gamma,
        pressure=args.pressure,
        Er=args.Er,
        n=args.n,
        Br=args.Br,
        m=args.m,
        phi=args.phi,
        dphi=args.dphi,
        rf=args.rf,
        c=args.c,
        steps=args.steps,
        tol=args.tol,
    )
    (args.output / "strip-footing-on-sand.supan").write_text(model)
    (args.output / "gravity.txt").write_text(gravity)
    (args.output / "footing.txt").write_text(footing)
    print(f"model written to {args.output}")


if __name__ == "__main__":
    main()
