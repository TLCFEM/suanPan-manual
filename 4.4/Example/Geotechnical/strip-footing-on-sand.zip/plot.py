#!/usr/bin/env python3
"""Plot the load-settlement curve and settlement contour of the example.

Run this script in the folder that contains the model, the amplitude files and
the HDF5 recorder output.  The required packages are numpy, matplotlib and
h5py.

    python plot.py --pressure 200
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

import h5py
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.size": 10,
        "axes.linewidth": 0.8,
        "axes.grid": True,
        "grid.color": "0.85",
        "grid.linewidth": 0.6,
        "lines.linewidth": 1.8,
        "savefig.bbox": "tight",
    }
)


def read_nodes(path: Path) -> dict[int, tuple[float, float]]:
    nodes = {}
    pattern = re.compile(r"^node\s+(\d+)\s+([-\d.eE+]+)\s+([-\d.eE+]+)")
    for line in path.read_text().splitlines():
        match = pattern.match(line)
        if match:
            nodes[int(match.group(1))] = (float(match.group(2)), float(match.group(3)))
    return nodes


def read_field(path: Path) -> dict[int, np.ndarray]:
    with h5py.File(path) as f:
        group = f[list(f.keys())[0]]
        return {
            int(re.search(r"(\d+)$", name).group(1)): group[name][:]
            for name in group.keys()
        }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pressure", type=float, default=200.0)
    parser.add_argument("--footing", type=float, default=1.0)
    parser.add_argument("--model", type=Path, default=Path("strip-footing-on-sand.supan"))
    args = parser.parse_args()

    nodes = read_nodes(args.model)
    field = read_field(Path("R1-U.h5"))
    tags = sorted(field)
    t = field[tags[0]][:, 0]

    # The footing pressure is zero until t=0.2 and then ramps linearly.
    q = np.clip((t - 0.2) / 0.8, 0.0, 1.0) * args.pressure
    k0 = int(np.argmin(abs(t - 0.2)))

    top = [(tag, nodes[tag]) for tag in tags if np.isclose(nodes[tag][1], 10.0)]
    centre = min(top, key=lambda item: item[1][0])[0]
    far = max(top, key=lambda item: item[1][0])[0]
    u_centre = field[centre][:, 2]
    u_far = field[far][:, 2]
    s = -(u_centre - u_centre[k0]) * 1000.0

    # The footing pressure is checked against the sum of the vertical reactions
    # over the loaded nodes. The reaction at t=0.2 (gravity only) is subtracted.
    footing_tags = [tag for tag, xy in top if xy[0] <= args.footing + 1e-9]
    loaded = max(nodes[tag][0] for tag in footing_tags) - min(nodes[tag][0] for tag in footing_tags)
    reaction = read_field(Path("R2-RF.h5"))
    total = -sum(reaction[tag][-1, 2] - reaction[tag][k0, 2] for tag in footing_tags)

    fig, ax = plt.subplots(figsize=(5.4, 4.0))
    ax.plot(s, q, color="black")
    ax.set_xlabel("footing settlement $s$ [mm]")
    ax.set_ylabel("average footing pressure $q$ [kPa]")
    ax.set_xlim(left=0)
    ax.set_ylim(bottom=0)
    ax.set_title(f"$s={s[-1]:.1f}$ mm at $q={q[-1]:.0f}$ kPa")
    fig.savefig("load-settlement.svg")
    plt.close(fig)

    x = np.array([nodes[tag][0] for tag in tags])
    y = np.array([nodes[tag][1] for tag in tags])
    du = np.array([(field[tag][-1, 2] - field[tag][k0, 2]) * 1000.0 for tag in tags])

    fig, ax = plt.subplots(figsize=(4.2, 7.0))
    levels = np.linspace(du.min(), 0.0, 21)
    contour = ax.tricontourf(x, y, du, levels=levels, cmap="viridis_r", extend="min")
    ax.plot([0.0, args.footing], [y.max(), y.max()], color="black", linewidth=4.0)
    ax.set_xlim(-0.1, x.max() + 0.1)
    ax.set_ylim(-0.4, y.max() + 1.0)
    ax.set_aspect("equal")
    ax.set_xlabel("$x$ [m]")
    ax.set_ylabel("$y$ [m]")
    ax.grid(False)
    cbar = fig.colorbar(contour, ax=ax, shrink=0.75, pad=0.02)
    cbar.set_label("additional vertical displacement [mm]")
    fig.savefig("settlement-contour.svg")
    plt.close(fig)

    print(f"reaction sum: {total:.2f} kN/m over {loaded:.2f} m, i.e. {total / loaded:.2f} kPa")
    print(f"gravity settlement: {u_centre[k0] * 1000.0:.2f} mm")
    print(f"additional centre settlement: {s[-1]:.2f} mm")
    print(f"additional far-field settlement: {-(u_far[-1] - u_far[k0]) * 1000.0:.2f} mm")


if __name__ == "__main__":
    main()
