node 1 0 0

material ConcreteTsai 1 3E4 30 3 2 2 .2 2E-3 1.2E-4
material MPF 2 2E5 400 .001

element SingleSection2D 1 1 1

# fix2 1 1 1

hdf5recorder 1 Node RF 1
hdf5recorder 2 Node U 1
